import datetime
def testme(event,context):
	date = datetime.datetime.now()
	alldays=[]
	for l in range(2):
		date += datetime.timedelta(days=1)
		print str(date)
		data={
	        "date": str(date),
	        "slots": [
	      	{
	          "start_time": str(date),
	          "duration": 0,
	          "availability": 0
	        }
	      ]
	    }
		alldays.append(data)
	result={"days":alldays}
	return result
# print testme("s","s")